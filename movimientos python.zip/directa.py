import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Parámetros del robot
x0, y0 = 1, 2  # Posición inicial
theta0 = np.radians(60)  # Orientación inicial en radianes
d1 = 2  # Distancia primera etapa
theta1 = np.radians(30)  # Rotación adicional en radianes
d2 = 3  # Distancia segunda etapa

# Cálculos de la primera etapa
x1 = x0 + d1 * np.cos(theta0)
y1 = y0 + d1 * np.sin(theta0)

# Cálculos de la segunda etapa
theta2 = theta0 + theta1
xf = x1 + d2 * np.cos(theta2)
yf = y1 + d2 * np.sin(theta2)

# Configuración de la figura
fig, ax = plt.subplots(figsize=(8, 6))
ax.set_xlim(0, 4)
ax.set_ylim(0, 8)
ax.axhline(0, color='black', lw=0.5, ls='--')
ax.axvline(0, color='black', lw=0.5, ls='--')
ax.grid()
ax.set_title('Animación de Transformación de Coordenadas: Robot Móvil')
ax.set_xlabel('X')
ax.set_ylabel('Y')

# Inicializar el punto del robot
robot, = ax.plot([], [], 'bo', markersize=10)  # Robot representado por un punto

# Inicializar la trayectoria
line, = ax.plot([], [], 'r-', lw=2)  # Línea roja para el movimiento

# Inicializar los vectores de movimiento
vector1 = ax.quiver(0, 0, 0, 0, angles='xy', scale_units='xy', scale=1, color='g', label='Movimiento 1')
vector2 = ax.quiver(0, 0, 0, 0, angles='xy', scale_units='xy', scale=1, color='orange', label='Movimiento 2')

# Datos de la animación
x_data = []
y_data = []

# Función de inicialización
def init():
    robot.set_data([], [])
    line.set_data([], [])
    vector1.set_UVC(0, 0)
    vector2.set_UVC(0, 0)
    return robot, line, vector1, vector2

# Función de actualización para la animación
def update(frame):
    if frame <= 20:  # Primera etapa (movimiento rectilíneo)
        progress = frame / 20
        x = x0 + progress * (x1 - x0)
        y = y0 + progress * (y1 - y0)

        # Actualizar el robot
        robot.set_data([x], [y])  # Asegúrate de que x y y sean listas
        x_data.append(x)
        y_data.append(y)
        
        # Actualizar el vector de movimiento 1
        vector1.set_UVC(x1 - x0, y1 - y0)  # Representar el movimiento completo
        vector1.set_offsets([x, y])  # Posicionar el vector en la posición actual del robot
    else:  # Segunda etapa (rotación y movimiento)
        progress = (frame - 20) / 20
        x = x1 + progress * (xf - x1)
        y = y1 + progress * (yf - y1)

        # Actualizar el robot
        robot.set_data([x], [y])
        x_data.append(x)
        y_data.append(y)
        
        # Actualizar el vector de movimiento 2
        vector2.set_UVC(xf - x1, yf - y1)  # Representar el movimiento completo
        vector2.set_offsets([x, y])  # Posicionar el vector en la posición actual del robot

    # Actualizar la trayectoria
    line.set_data(x_data, y_data)

    return robot, line, vector1, vector2

# Crear la animación
ani = animation.FuncAnimation(fig, update, frames=41, init_func=init, blit=True, repeat=False)

# Guardar la animación como un archivo GIF usando Pillow
ani.save('robot_movil_animacion_con_vectores.gif', writer='pillow', fps=10)

# Mostrar la animación
plt.legend()
plt.show()